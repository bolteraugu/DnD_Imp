import React from "react";

import Providers from "./src/navigation";

export default function App() {
  console.disableYellowBox = true;
  return <Providers />;
}
