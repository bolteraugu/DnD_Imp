import React from "react";
import { Text } from "react-native";

export default function PlayerScreen() {
  return <Text>Main</Text>;
  // TOP NEESTED TAB NAVIGATION
  // MAIN | NOTES | SPELLS

  // MAIN SHOWS ALL CARD INFO IN A DIFF LAYOUT

  // NOTES IS SIMPLE TITLE,CONTENT FLATLIST WITH INPUT

  // CHAT SHOULD BE VISIBLE AT ALL TIMES
  // IDEALLY NOT HAVING TO BE RELOADED EACH TIME
}
