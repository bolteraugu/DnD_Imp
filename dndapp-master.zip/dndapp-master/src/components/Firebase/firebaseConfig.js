// Rename this file to "firebaeConfig.js" before use
// Replace all XXXXs with real Firebase API keys

export default {
  apiKey: "AIzaSyD-18Zl_Rp_UMZeYqcry6ITDwe4Kxue-xo",
  authDomain: "dungeon-minion-5e.firebaseapp.com",
  databaseURL: "https://dungeon-minion-5e.firebaseio.com",
  projectId: "dungeon-minion-5e",
  storageBucket: "dungeon-minion-5e.appspot.com",
  messagingSenderId: "724743390174",
  appId: "1:724743390174:web:50ecd3146b2551ac65134f",
  measurementId: "G-CP3D67ZR4P",
};
